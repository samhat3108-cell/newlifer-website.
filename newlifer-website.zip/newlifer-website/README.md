# Newlifer.com cleaning website

Responsive website with About Us, Services, Our Work (clearly labeled example jobs), How It Works, FAQs, a booking request form, admin dashboard, booking status management, CSV export, customer AI concierge and private admin AI assistant.

## Deploy on Render
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Add environment variable `ADMIN_PASSWORD` with a long, unique password.
- Optional AI: add `OPENAI_API_KEY` and optionally `OPENAI_MODEL` (default `gpt-4o-mini`). OpenAI API usage is billed separately.

## Important before public launch
- Prices are placeholders; confirm them before publishing.
- Add your actual business phone/email, service area, privacy notice and business details.
- Booking data is stored in `data/bookings.json`. Render's default filesystem is ephemeral, so this simple setup is not suitable for relying on real customer bookings on a free deployment; configure persistent storage or a database before accepting real bookings.
- The booking form records requests but does not send email/SMS confirmations.
- Admin sessions are in memory and expire after 12 hours. For a larger business, use a database, stronger production authentication/rate limiting and backups.
